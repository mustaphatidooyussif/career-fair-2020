========================   AUTHORS =====================================
		Mustapha Tidoo Yussif and Samuel Atule					       *
						       
==========================Tasks Completed ============================== 
				Task 1 
				Task 2							       


==========================Program Requirements==========================

 1. The program must be run with python 3.5 or later. 
2. The program expects the correct filenames passed in the terminals as
  specified in the tasks descriptions. 

Example:
	python task1.py covid_data.csv population_data.csv
	python task2.py covid_data.csv partial_time_series.csv